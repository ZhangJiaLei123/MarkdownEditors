(function () {
  initHashLevelRedirects()
  initMobileMenu()
  initVideoModal()
  initNewNavLinks()

 
  function initHashLevelRedirects() {
    checkForHashRedirect(/list\.html$/, {
      key: '/v2/guide/list.html#维护状态'
    })
    checkForHashRedirect(/components\.html$/, {
      '什么是组件？': '/v2/guide/components.html',
      '使用组件': '/v2/guide/components-registration.html',
      '全局注册': '/v2/guide/components-registration.html#全局注册',
      '局部注册': '/v2/guide/components-registration.html#局部注册',
      'DOM-模板解析注意事项': '/v2/guide/components.html#解析-DOM-模板时的注意事项',
      'DOM-模板解析说明': '/v2/guide/components.html#解析-DOM-模板时的注意事项',
      'data-必须是函数': '/v2/guide/components.html#data-必须是一个函数',
      '组件组合': '/v2/guide/components.html#组件的组织',
      'Prop': '/v2/guide/components.html#通过-Prop-向子组件传递数据',
      'Props': '/v2/guide/components.html#通过-Prop-向子组件传递数据',
      '使用-Prop-传递数据': '/v2/guide/components.html#通过-Prop-向子组件传递数据',
      'camelCase-vs-kebab-case': '/v2/guide/components-props.html#Prop-的大小写-camelCase-vs-kebab-case',
      '动态-Prop': '/v2/guide/components-props.html#静态的和动态的-Prop',
      '字面量语法-vs-动态语法': '/v2/guide/components-props.html#静态的和动态的-Prop',
      '单向数据流': '/v2/guide/components-props.html#单向数据流',
      'Prop-验证': '/v2/guide/components-props.html#Prop-验证',
      '非-Prop-特性': '/v2/guide/components-props.html#非-Prop-的特性',
      '替换-合并现有的特性': '/v2/guide/components-props.html#替换-合并已有的特性',
      '自定义事件': '/v2/guide/components.html#监听子组件事件',
      '使用-v-on-绑定自定义事件': '/v2/guide/components.html#监听子组件事件',
      '给组件绑定原生事件': '/v2/guide/components-custom-events.html#将原生事件绑定到组件',
      'sync-修饰符': '/v2/guide/components-custom-events.html#sync-修饰符',
      '使用自定义事件的表单输入组件': '/v2/guide/components-custom-events.html#将原生事件绑定到组件',
      '自定义组件的-v-model': '/v2/guide/components-custom-events.html#自定义组件的-v-model',
      '在组件上使用-v-model': '/v2/guide/components-custom-events.html#自定义组件的-v-model',
      '非父子组件的通信': '/v2/guide/state-management.html',
      '使用插槽分发内容': '/v2/guide/components.html#通过插槽分发内容',
      '编译作用域': '/v2/guide/components-slots.html#编译作用域',
      '单个插槽': '/v2/guide/components-slots.html#插槽内容',
      '具名插槽': '/v2/guide/components-slots.html#具名插槽',
      '作用域插槽': '/v2/guide/components-slots.html#作用域插槽',
      '动态组件': '/v2/guide/components.html#动态组件',
      'keep-alive': '/v2/guide/components-dynamic-async.html#在动态组件上使用-keep-alive',
      '杂项': '/v2/guide/components-edge-cases.html',
      '编写可复用组件': '/v2/guide/components.html#组件的组织',
      '子组件引用': '/v2/guide/components-edge-cases.html#访问子组件实例或子元素',
      '子组件索引': '/v2/guide/components-edge-cases.html#访问子组件实例或子元素',
      '异步组件': '/v2/guide/components-dynamic-async.html#异步组件',
      '高级异步组件': '/v2/guide/components-dynamic-async.html#处理加载状态',
      '组件命名约定': '/v2/guide/components-registration.html#组件名',
      '递归组件': '/v2/guide/components-edge-cases.html#递归组件',
      '组件间的循环引用': '/v2/guide/components-edge-cases.html#组件之间的循环引用',
      '内联模板': '/v2/guide/components-edge-cases.html#内联模板',
      'X-Templates': '/v2/guide/components-edge-cases.html#X-Templates',
      '对低开销的静态组件使用-v-once': '/v2/guide/components-edge-cases.html#通过-v-once-创建低开销的静态组件'
    })
    function checkForHashRedirect(pageRegex, redirects) {
      // Abort if the current page doesn't match the page regex
      if (!pageRegex.test(window.location.pathname)) return

      var redirectPath = redirects[decodeURIComponent(window.location.hash.slice(1))]
      if (redirectPath) {
        window.location.href = window.location.origin + redirectPath
      }
    }
  }


  /**
   * Initializes a list of links to mark as "updated" by adding a red dot next to them
   */

  function initNewNavLinks() {
    var linkExpirePeriod = 60 * 24 * 3600 * 1000 // 2 months
    var links = [
      {
        title: 'Learn',
        updatedOn: new Date("Fri Mar 1 2019")
      },
      {
        title: 'Examples',
        updatedOn: new Date("Fri Mar 1 2019")
      }
    ]
    var today = new Date().getTime()
    var updatedLinks = links
      .filter(function (link) {
        return link.updatedOn.getTime() + linkExpirePeriod > today
      })
      .map(function (link) {
        return link.title
      })

    var navLinks = document.querySelectorAll('#nav a.nav-link')
    var newLinks = []
    navLinks.forEach(function (link) {
      if (updatedLinks.indexOf(link.textContent) !== -1) {
        newLinks.push(link)
      }
    })
    newLinks.forEach(function (link) {
      var classes = link.classList
      var linkKey = `visisted-${link.textContent}`
      if (localStorage.getItem(linkKey) || classes.contains('current')) {
        classes.remove('updated-link')
        localStorage.setItem(linkKey, 'true')
      } else {
        classes.add('new')
      }
    })
  }

  /**
   * Mobile burger menu button and gesture for toggling sidebar
   */

  function initMobileMenu () {
    var mobileBar = document.getElementById('mobile-bar')
    var sidebar = document.querySelector('.sidebar')
    var menuButton = mobileBar.querySelector('.menu-button')

    menuButton.addEventListener('click', function () {
      sidebar.classList.toggle('open')
    })

    document.body.addEventListener('click', function (e) {
      if (e.target !== menuButton && !sidebar.contains(e.target)) {
        sidebar.classList.remove('open')
      }
    })

    // Toggle sidebar on swipe
    var start = {}, end = {}

    document.body.addEventListener('touchstart', function (e) {
      start.x = e.changedTouches[0].clientX
      start.y = e.changedTouches[0].clientY
    })

    document.body.addEventListener('touchend', function (e) {
      end.y = e.changedTouches[0].clientY
      end.x = e.changedTouches[0].clientX

      var xDiff = end.x - start.x
      var yDiff = end.y - start.y

      if (Math.abs(xDiff) > Math.abs(yDiff)) {
        if (xDiff > 0 && start.x <= 80) sidebar.classList.add('open')
        else sidebar.classList.remove('open')
      }
    })
  }

  /**
  * Modal Video Player
  */
  function initVideoModal () {
    var modalButton = document.getElementById('modal-player')
    var videoModal = document.getElementById('video-modal')

    if (!modalButton || !videoModal) {
      return
    }

    var videoWrapper = videoModal.querySelector('.video-space')
    var overlay = document.createElement('div')
        overlay.className = 'overlay'
    var isOpen = false

    modalButton.addEventListener('click', function(event) {
      event.stopPropagation()
      videoModal.classList.toggle('open')
      document.body.classList.toggle('stop-scroll')
      document.body.appendChild(overlay)
      videoWrapper.innerHTML = '<iframe style="height: 100%; left: 0; position: absolute; top: 0; width: 100%;" src="//player.youku.com/embed/XMzMwMTYyODMyNA==?autoplay=true&client_id=37ae6144009e277d" frameborder="0" allowfullscreen></iframe>'
      isOpen = true
    })

    document.body.addEventListener('click', function(e) {
      if (isOpen && e.target !== modalButton && !videoModal.contains(e.target)) {
        videoModal.classList.remove('open')
        document.body.classList.remove('stop-scroll')
        document.body.removeChild(overlay)
        videoWrapper.innerHTML = ''
        isOpen = false
      }
    })
  }




})()
